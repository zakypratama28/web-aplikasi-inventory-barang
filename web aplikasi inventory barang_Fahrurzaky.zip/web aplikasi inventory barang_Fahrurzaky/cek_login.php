<?php 
  session_start();
  include 'koneksi.php';

  $user = $_POST['username'];
  $pass = $_POST['password'];

  $data = mysqli_query($koneksi, "SELECT * FROM tabel_user WHERE username='$user' AND password='$pass'") or die(mysqli_error($koneksi));
  
  if(mysqli_num_rows($data) > 0) {
    $row = mysqli_fetch_array($data);

    $_SESSION['user'] = $row['username'];
    $_SESSION['pass'] = $row['password'];
    $_SESSION['status'] = 'login';

    header("location: barang.php");
  } else {
?>
  <script>
    alert("Data anda tidak valid");
    window.location.href = "login.php";
  </script>
<?php
  }

?>