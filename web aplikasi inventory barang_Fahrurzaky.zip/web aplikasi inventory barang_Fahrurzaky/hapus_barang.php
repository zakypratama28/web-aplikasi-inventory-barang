<?php
// include database connection file 
include 'koneksi.php';
$id_barang = $_GET['id_barang'];
$result = mysqli_query($koneksi, "DELETE FROM tabel_barang WHERE id_barang='$id_barang'"); 
header("Location:barang.php");
?>
