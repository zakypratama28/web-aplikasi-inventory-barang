<?php
// include database connection file 
include 'koneksi.php';
$id_pelanggan = $_GET['id_pelanggan'];
$result = mysqli_query($koneksi, "DELETE FROM tabel_pelanggan WHERE id_pelanggan='$id_pelanggan'"); 
header("Location:pelanggan.php");
?>