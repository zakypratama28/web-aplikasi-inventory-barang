<?php
// include database connection file 
include 'koneksi.php';
$id_pembelian = $_GET['id_pembelian'];
$result = mysqli_query($koneksi, "DELETE FROM tabel_pembelian WHERE id_pembelian='$id_pembelian'"); 
header("Location:pembelian.php");
?>