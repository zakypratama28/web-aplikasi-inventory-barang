<?php 
  include 'koneksi.php';
  include 'cek_status_login.php';
  $user = $_SESSION['user'];
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
  <title>Pembayaran</title>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
    <a class="navbar-brand" href="#">Welcome To GzGaming <?php if ($user != '') echo $user ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <form class="form-inline my-2 my-lg-0 ml-auto">

      </form>
      <div class="icon ml-4">
        <h5>

          <a href="logout.php"><i class="fas fa-sign-out-alt mr-3 bg-dark"></i>
          <button class="btn btn-outline-success my-2 my-sm-0 bg-white" type="logout">Logout</button></a>
        </h5>
      </div>
    </div>
  </nav>
  <div class="row no-gutters mt-5">
    <div class="col-md-2 bg-dark mt-2 pr-3 pt-4">
      <ul class="nav flex-column ml-3 mb-5">
        <li class="nav-item">
          <a class="nav-link active text-white" href="barang.php"><i class="fas fa-home mr-2"></i>Home</a>
          <hr class="bg-secondary">
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="barang.php"><i class="fas fa-cubes mr-2"></i>Barang</a>
          <hr class="bg-secondary">
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="pelanggan.php"><i class="fas fa-users mr-2"></i>Pelanggan</a>
          <hr class="bg-secondary">
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="pembelian.php"><i class="fas fa-tags mr-2"></i>Pembelian</a>
          <hr class="bg-secondary">
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="pembayaran.php"><i class="fas fa-store mr-2"></i>Metode Pembayaran</a>
          <hr class="bg-secondary">
        </li>
      </ul>
    </div>

  <div class="col-md-10 p-5 pt-2">
    <h3><i class="fas fa-calendar-alt mr-2"></i> Daftar Bayar</h3><hr>
        <a href="tambah_pembayaran.php" class="btn btn-primary mb-2"> <i class="fas fa-plus-circle mr-2"></i>TAMBAH DATA</a>
        <table class="table table-striped table-bordered">
       <thead>
       	<tr>
       		<th scope="col">No</th>
          <th scope="col">ID Detail Pembelian</th>
          <th scope="col">ID Barang</th>
          <th scope="col">QTY</th>
       		<th scope="col">Total Pembayaran</th>


       	</tr>
       </thead>
       <tbody>
       	<?php
       	include 'koneksi.php';
       	$no = 1;
       	$sql = mysqli_query($koneksi,"select * from tabel_detail");
       	while ($data = mysqli_fetch_array($sql)) {
       	?>

       	<tr>
       		<td><?php echo $no++; ?></td>
           <td><?php echo $data['id_det_pembelian']; ?></td>
           <td><?php echo $data['id_barang']; ?></td>
       		<td><?php echo $data['qty']; ?></td>
       		<td><?php echo $data['total_pembayaran']; ?></td>
       	

       </tr>
       	<?php
       		# code...
       	}
       	?>
      
        </tbody>
      </table>
  </div>

</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>