<?php 
    include('koneksi.php');

    $id_barang = $_POST['id_barang'];
    $nama_barang = $_POST['nama_barang'];
    $harga = $_POST['harga'];
    
    $input = mysqli_query($koneksi,"INSERT INTO tabel_barang VALUES('$id_barang','$nama_barang','$harga')") or die(mysqli_error($koneksi));
    if($input){
        echo "Data Berhasil Disimpan";
        header("location:barang.php"); 
    }else{
        echo "Gagal Disimpan";
    }   
?>