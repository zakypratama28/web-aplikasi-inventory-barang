<?php 
    include('koneksi.php');

    $id_pelanggan = $_POST['id_pelanggan'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $telp = $_POST['telp'];

    $input = mysqli_query($koneksi,"INSERT INTO tabel_pelanggan VALUES('$id_pelanggan','$nama_pelanggan','$alamat','$telp')") or die(mysqli_error($koneksi));
    if($input){
        echo "Data Berhasil Disimpan";
        header("location:pelanggan.php"); 
    }else{
        echo "Gagal Disimpan";
    }   
?>