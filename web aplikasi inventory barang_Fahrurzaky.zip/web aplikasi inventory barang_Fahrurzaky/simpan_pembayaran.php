<?php 
    include('koneksi.php');

    $id_det_pembelian = $_POST['id_det_pembelian'];
    $id_barang = $_POST['id_barang'];
    $qty = $_POST['qty'];
    $total_pembayaran = $_POST['total_pembayaran'];

    $input = mysqli_query($koneksi,"INSERT INTO tabel_detail VALUES('$id_det_pembelian','$id_barang','$qty','$total_pembayaran')") or die(mysqli_error($koneksi));
    if($input){
        echo "Data Berhasil Disimpan";
        header("location:pembayaran.php"); 
    }else{
        echo "Gagal Disimpan";
    }   
?>