<?php 
    include('koneksi.php');

    $id_pembelian = $_POST['id_pembelian'];
    $id_pelanggan = $_POST['id_pelanggan'];
    $id_det_pembelian = $_POST['id_det_pembelian'];

    $input = mysqli_query($koneksi,"INSERT INTO tabel_pembelian VALUES('$id_pembelian','$id_pelanggan','$id_det_pembelian')") or die(mysqli_error($koneksi));
    if($input){
        echo "Data Berhasil Disimpan";
        header("location:pembelian.php"); 
    }else{
        echo "Gagal Disimpan";
    }   
?>