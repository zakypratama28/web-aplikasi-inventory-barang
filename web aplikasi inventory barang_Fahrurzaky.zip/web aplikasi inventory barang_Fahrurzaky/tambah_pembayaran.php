<?php 
  include 'koneksi.php';
  include 'cek_status_login.php';
  $user = $_SESSION['user'];
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
  <title>Pembelian</title>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
    <a class="navbar-brand" href="#">Welcome To GzGaming <?php if ($user != '') echo $user ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <form class="form-inline my-2 my-lg-0 ml-auto">

      </form>
      <div class="icon ml-4">
        <h5>

          <a href="logout.php"><i class="fas fa-sign-out-alt mr-3 bg-dark"></i>
          <button class="btn btn-outline-success my-2 my-sm-0 bg-white" type="logout">Logout</button></a>
        </h5>
      </div>
    </div>
  </nav>
  <div class="row no-gutters mt-5">
    <div class="col-md-2 bg-dark mt-2 pr-3 pt-4">
      <ul class="nav flex-column ml-3 mb-5">
        <li class="nav-item">
          <a class="nav-link active text-white" href="barang.php"><i class="fas fa-home mr-2"></i>Home</a>
          <hr class="bg-secondary">
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="barang.php"><i class="fas fa-cubes mr-2"></i>Barang</a>
          <hr class="bg-secondary">
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="pelanggan.php"><i class="fas fa-users mr-2"></i>Pelanggan</a>
          <hr class="bg-secondary">
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="pembelian.php"><i class="fas fa-tags mr-2"></i>Pembelian</a>
          <hr class="bg-secondary">
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="pembayaran.php"><i class="fas fa-store mr-2"></i>Metode Pembayaran</a>
          <hr class="bg-secondary">
        </li>
      </ul>
    </div>
		<div class="col-md-10 p-5 pt-2">
			<h3><i class="fas fa-users mr-2"></i> Tambah Data Baru</h3>
			<hr>
			<form action="simpan_pembayaran.php" method="post">
				<div class="form-row">
					<div class="form-group col-md-6">
						<label >ID Detail Pembelian</label>
						<input type="text" name="id_det_pembelian" class="form-control" id="id_det_pembelian">
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-4">
						<label >ID Barang</label>
						<input type="text" name="id_barang" class="form-control" id="id_barang">
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label >QTY</label>
						<input type="text" name="qty" class="form-control" id="qty">
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label >Total Pembayaran</label>
						<input type="text" name="total_pembayaran" class="form-control" id="total_pembayaran">
					</div>
			
			
				<button type="submit" class="btn btn-primary">SIMPAN</button>
			</form>
		</div>
	</div>
</body>
</html>