<?php
// include database connection file 
include 'koneksi.php';
$id_barang= $_POST['id_barang'];
$nama_barang=$_POST['nama_barang'];
$harga=$_POST['harga'];
$result = mysqli_query($koneksi, "UPDATE tabel_barang SET nama_barang='$nama_barang',harga='$harga' WHERE id_barang='$id_barang'") or die(mysqli_error($koneksi));
// Redirect to homepage to display updated user in list
header("Location: barang.php");
?>
