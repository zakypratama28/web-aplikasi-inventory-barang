<?php
// include database connection file 
include 'koneksi.php';
$id_pelanggan = $_POST['id_pelanggan'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$alamat = $_POST['alamat'];
$telp = $_POST['telp'];
$result = mysqli_query($koneksi, "UPDATE tabel_pelanggan SET nama_pelanggan='$nama_pelanggan',alamat='$alamat',telp='$telp' WHERE id_pelanggan='$id_pelanggan'") or die(mysqli_error($koneksi));
// Redirect to homepage to display updated user in list
if($result) {
    header("Location: pelanggan.php");
} else {
    echo "gagal";
}

?>
