<?php
// include database connection file 
include 'koneksi.php';
$id_pembelian = $_POST['id_pembelian'];
$id_pelanggan = $_POST['id_pelanggan'];
$id_det_pembelian = $_POST['id_det_pembelian'];
$result = mysqli_query($koneksi, "UPDATE tabel_pembelian SET id_pelanggan='$id_pelanggan',id_det_pembelian='$id_det_pembelian' WHERE id_pembelian='$id_pembelian'") or die(mysqli_error($koneksi));
// Redirect to homepage to display updated user in list
if($result) {
    header("Location: pembelian.php");
} else {
    echo "gagal";
}

?>
